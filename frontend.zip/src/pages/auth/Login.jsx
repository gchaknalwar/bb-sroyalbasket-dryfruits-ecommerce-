import { useEffect, useMemo, useState } from "react";

import {
  ArrowRight,
  Eye,
  EyeOff,
  LockKeyhole,
  Mail,
  Phone,
  UserRound,
} from "lucide-react";

import { Link, useLocation, useNavigate } from "react-router-dom";

import toast from "react-hot-toast";

import { useAuth } from "../../context/AuthContext";

const DEFAULT_REDIRECT = "/account";

/* --------------------------------
   Safe Redirect
-------------------------------- */

const getSafeRedirect = (location) => {
  const from = location.state?.from;

  if (typeof from !== "string") {
    return DEFAULT_REDIRECT;
  }

  // Only allow internal application routes.
  if (!from.startsWith("/") || from.startsWith("//")) {
    return DEFAULT_REDIRECT;
  }

  return from;
};

/* --------------------------------
   Register Page
-------------------------------- */

export default function Register() {
  const navigate = useNavigate();
  const location = useLocation();

  const { register, isAuthenticated, loading } = useAuth();

  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });

  const [showPassword, setShowPassword] = useState(false);

  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [submitting, setSubmitting] = useState(false);

  const redirectTo = useMemo(() => getSafeRedirect(location), [location]);

  /* --------------------------------
     Redirect Authenticated User
  -------------------------------- */

  useEffect(() => {
    if (!loading && isAuthenticated) {
      navigate(redirectTo, {
        replace: true,
      });
    }
  }, [loading, isAuthenticated, navigate, redirectTo]);

  /* --------------------------------
     Handle Input
  -------------------------------- */

  const handleChange = (event) => {
    const { name, value } = event.target;

    setForm((current) => ({
      ...current,
      [name]: name === "phone" ? value.replace(/\D/g, "").slice(0, 10) : value,
    }));
  };

  /* --------------------------------
     Submit Registration
  -------------------------------- */

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (submitting) {
      return;
    }

    const firstName = form.firstName.trim();
    const lastName = form.lastName.trim();
    const email = form.email.trim().toLowerCase();
    const phone = form.phone.trim();
    const password = form.password;

    if (!firstName || !lastName) {
      toast.error("Please enter your first and last name.");
      return;
    }

    if (!email) {
      toast.error("Please enter your email address.");
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Please enter a valid email address.");
      return;
    }

    if (!/^[6-9]\d{9}$/.test(phone)) {
      toast.error("Please enter a valid 10-digit mobile number.");
      return;
    }

    if (password.length < 6) {
      toast.error("Password must be at least 6 characters.");
      return;
    }

    if (password !== form.confirmPassword) {
      toast.error("Passwords do not match.");
      return;
    }

    setSubmitting(true);

    try {
      const result = await register({
        firstName,
        lastName,
        email,
        phone,
        password,
      });

      if (!result?.success) {
        toast.error(result?.message || "Unable to create your account.");
        return;
      }

      toast.success("Account created successfully!");

      navigate(redirectTo, {
        replace: true,
      });
    } catch (error) {
      console.error("Registration page error:", error);

      toast.error("Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="min-h-[calc(100vh-80px)] bg-[#f8f4ec] px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto grid max-w-6xl overflow-hidden rounded-[2rem] border border-[#e7dcc9] bg-white shadow-[0_25px_80px_rgba(77,55,29,0.10)] lg:grid-cols-2">
        {/* Brand Panel */}

        <section className="relative hidden overflow-hidden bg-[#3f2819] p-10 text-white lg:flex lg:flex-col lg:justify-between xl:p-14">
          <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-[#c79a5b]/20 blur-3xl" />

          <div className="absolute -bottom-28 -left-20 h-80 w-80 rounded-full bg-[#e7c58f]/10 blur-3xl" />

          <div className="relative">
            <p className="mb-5 text-sm font-semibold uppercase tracking-[0.3em] text-[#e7c58f]">
              BB&apos;s Royal Basket
            </p>

            <h1 className="max-w-md text-4xl font-semibold leading-tight xl:text-5xl">
              Your premium basket,
              <br />
              always within reach.
            </h1>

            <p className="mt-6 max-w-md text-sm leading-7 text-white/70">
              Create your account to keep your orders, delivery details and
              shopping experience organized in one place.
            </p>
          </div>

          <div className="relative">
            <p className="text-sm text-white/60">
              Premium dry fruits • Seeds • Dried berries
            </p>
          </div>
        </section>

        {/* Register Form */}

        <section className="p-6 sm:p-10 lg:p-12 xl:p-14">
          <div className="mx-auto max-w-md">
            <div className="mb-7">
              <div className="mb-5 inline-flex rounded-2xl bg-[#f5ede1] p-3 text-[#6b4528]">
                <UserRound size={24} />
              </div>

              <h2 className="text-3xl font-semibold tracking-tight text-[#2d2118]">
                Create your account
              </h2>

              <p className="mt-2 text-sm leading-6 text-[#75695d]">
                Join BB&apos;s Royal Basket and manage your orders easily.
              </p>
            </div>

            <form onSubmit={handleSubmit} noValidate className="space-y-4">
              {/* Name */}

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="firstName"
                    className="mb-2 block text-sm font-medium text-[#3d3025]"
                  >
                    First name
                  </label>

                  <input
                    id="firstName"
                    name="firstName"
                    type="text"
                    value={form.firstName}
                    onChange={handleChange}
                    autoComplete="given-name"
                    disabled={submitting}
                    placeholder="First name"
                    className="h-12 w-full rounded-xl border border-[#ded2c1] bg-[#fcfaf7] px-4 text-sm text-[#2d2118] outline-none transition placeholder:text-[#aaa093] focus:border-[#9a6b39] focus:ring-4 focus:ring-[#9a6b39]/10 disabled:cursor-not-allowed disabled:opacity-60"
                  />
                </div>

                <div>
                  <label
                    htmlFor="lastName"
                    className="mb-2 block text-sm font-medium text-[#3d3025]"
                  >
                    Last name
                  </label>

                  <input
                    id="lastName"
                    name="lastName"
                    type="text"
                    value={form.lastName}
                    onChange={handleChange}
                    autoComplete="family-name"
                    disabled={submitting}
                    placeholder="Last name"
                    className="h-12 w-full rounded-xl border border-[#ded2c1] bg-[#fcfaf7] px-4 text-sm text-[#2d2118] outline-none transition placeholder:text-[#aaa093] focus:border-[#9a6b39] focus:ring-4 focus:ring-[#9a6b39]/10 disabled:cursor-not-allowed disabled:opacity-60"
                  />
                </div>
              </div>

              {/* Email */}

              <div>
                <label
                  htmlFor="email"
                  className="mb-2 block text-sm font-medium text-[#3d3025]"
                >
                  Email address
                </label>

                <div className="relative">
                  <Mail
                    size={18}
                    aria-hidden="true"
                    className="absolute left-4 top-1/2 -translate-y-1/2 text-[#9b8b7a]"
                  />

                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={form.email}
                    onChange={handleChange}
                    autoComplete="email"
                    autoCapitalize="none"
                    spellCheck="false"
                    disabled={submitting}
                    placeholder="you@example.com"
                    className="h-12 w-full rounded-xl border border-[#ded2c1] bg-[#fcfaf7] pl-11 pr-4 text-sm text-[#2d2118] outline-none transition placeholder:text-[#aaa093] focus:border-[#9a6b39] focus:ring-4 focus:ring-[#9a6b39]/10 disabled:cursor-not-allowed disabled:opacity-60"
                  />
                </div>
              </div>

              {/* Phone */}

              <div>
                <label
                  htmlFor="phone"
                  className="mb-2 block text-sm font-medium text-[#3d3025]"
                >
                  Mobile number
                </label>

                <div className="relative">
                  <Phone
                    size={18}
                    aria-hidden="true"
                    className="absolute left-4 top-1/2 -translate-y-1/2 text-[#9b8b7a]"
                  />

                  <input
                    id="phone"
                    name="phone"
                    type="tel"
                    inputMode="numeric"
                    value={form.phone}
                    onChange={handleChange}
                    autoComplete="tel"
                    maxLength={10}
                    disabled={submitting}
                    placeholder="10-digit mobile number"
                    className="h-12 w-full rounded-xl border border-[#ded2c1] bg-[#fcfaf7] pl-11 pr-4 text-sm text-[#2d2118] outline-none transition placeholder:text-[#aaa093] focus:border-[#9a6b39] focus:ring-4 focus:ring-[#9a6b39]/10 disabled:cursor-not-allowed disabled:opacity-60"
                  />
                </div>
              </div>

              {/* Password */}

              <div>
                <label
                  htmlFor="password"
                  className="mb-2 block text-sm font-medium text-[#3d3025]"
                >
                  Password
                </label>

                <div className="relative">
                  <LockKeyhole
                    size={18}
                    aria-hidden="true"
                    className="absolute left-4 top-1/2 -translate-y-1/2 text-[#9b8b7a]"
                  />

                  <input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    value={form.password}
                    onChange={handleChange}
                    autoComplete="new-password"
                    disabled={submitting}
                    placeholder="At least 6 characters"
                    className="h-12 w-full rounded-xl border border-[#ded2c1] bg-[#fcfaf7] pl-11 pr-12 text-sm text-[#2d2118] outline-none transition placeholder:text-[#aaa093] focus:border-[#9a6b39] focus:ring-4 focus:ring-[#9a6b39]/10 disabled:cursor-not-allowed disabled:opacity-60"
                  />

                  <button
                    type="button"
                    onClick={() => setShowPassword((value) => !value)}
                    disabled={submitting}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-[#8f8172] transition hover:text-[#4b301e] disabled:cursor-not-allowed disabled:opacity-50"
                    aria-label={
                      showPassword ? "Hide password" : "Show password"
                    }
                    aria-pressed={showPassword}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}

              <div>
                <label
                  htmlFor="confirmPassword"
                  className="mb-2 block text-sm font-medium text-[#3d3025]"
                >
                  Confirm password
                </label>

                <div className="relative">
                  <LockKeyhole
                    size={18}
                    aria-hidden="true"
                    className="absolute left-4 top-1/2 -translate-y-1/2 text-[#9b8b7a]"
                  />

                  <input
                    id="confirmPassword"
                    name="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    value={form.confirmPassword}
                    onChange={handleChange}
                    autoComplete="new-password"
                    disabled={submitting}
                    placeholder="Repeat your password"
                    className="h-12 w-full rounded-xl border border-[#ded2c1] bg-[#fcfaf7] pl-11 pr-12 text-sm text-[#2d2118] outline-none transition placeholder:text-[#aaa093] focus:border-[#9a6b39] focus:ring-4 focus:ring-[#9a6b39]/10 disabled:cursor-not-allowed disabled:opacity-60"
                  />

                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword((value) => !value)}
                    disabled={submitting}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-[#8f8172] transition hover:text-[#4b301e] disabled:cursor-not-allowed disabled:opacity-50"
                    aria-label={
                      showConfirmPassword ? "Hide password" : "Show password"
                    }
                    aria-pressed={showConfirmPassword}
                  >
                    {showConfirmPassword ? (
                      <EyeOff size={18} />
                    ) : (
                      <Eye size={18} />
                    )}
                  </button>
                </div>
              </div>

              {/* Submit */}

              <button
                type="submit"
                disabled={submitting || loading}
                className="mt-2 flex h-13 w-full items-center justify-center gap-2 rounded-xl bg-[#4b301e] px-5 text-sm font-semibold text-white shadow-lg shadow-[#4b301e]/15 transition hover:bg-[#362115] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {submitting ? (
                  <>
                    <span
                      aria-hidden="true"
                      className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white"
                    />
                    Creating account...
                  </>
                ) : (
                  <>
                    Create account
                    <ArrowRight size={18} aria-hidden="true" />
                  </>
                )}
              </button>
            </form>

            {/* Login Link */}

            <p className="mt-6 text-center text-sm text-[#75695d]">
              Already have an account?{" "}
              <Link
                to="/login"
                state={location.state}
                className="font-semibold text-[#6b4528] hover:text-[#3f2819]"
              >
                Sign in
              </Link>
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}
